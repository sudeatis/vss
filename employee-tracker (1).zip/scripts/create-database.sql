-- Kullanıcılar tablosu
CREATE TABLE IF NOT EXISTS users (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(100),
  created_at TIMESTAMP DEFAULT NOW()
);

-- İş kayıtları tablosu
CREATE TABLE IF NOT EXISTS work_entries (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  username VARCHAR(50) NOT NULL,
  task TEXT NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  duration VARCHAR(20) NOT NULL,
  work_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Demo kullanıcıları ekle
INSERT INTO users (username, password, full_name) VALUES 
  ('ahmet', '123456', 'Ahmet Yılmaz'),
  ('ayse', '123456', 'Ayşe Demir'),
  ('mehmet', '123456', 'Mehmet Kaya'),
  ('fatma', '123456', 'Fatma Özkan'),
  ('ali', '123456', 'Ali Çelik')
ON CONFLICT (username) DO NOTHING;

-- Örnek iş kayıtları
INSERT INTO work_entries (user_id, username, task, start_time, end_time, duration, work_date) 
SELECT 
  u.id,
  u.username,
  'Örnek iş kaydı - ' || u.full_name,
  '09:00',
  '17:00',
  '8s 0dk',
  CURRENT_DATE
FROM users u
ON CONFLICT DO NOTHING;

-- Önce mevcut tabloları temizle (varsa)
DROP TABLE IF EXISTS work_entries;
DROP TABLE IF EXISTS users;

-- Kullanıcılar tablosu (admin rolü eklendi)
CREATE TABLE users (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(100),
  role VARCHAR(20) DEFAULT 'employee',
  created_at TIMESTAMP DEFAULT NOW()
);

-- İş kayıtları tablosu (geliştirilmiş)
CREATE TABLE work_entries (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  username VARCHAR(50) NOT NULL,
  full_name VARCHAR(100),
  task TEXT NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  duration VARCHAR(20) NOT NULL,
  work_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Admin kullanıcısı ekle
INSERT INTO users (username, password, full_name, role) VALUES 
  ('admin', 'admin123', 'Sistem Yöneticisi', 'admin');

-- Demo çalışanları ekle
INSERT INTO users (username, password, full_name, role) VALUES 
  ('ahmet', '123456', 'Ahmet Yılmaz', 'employee'),
  ('ayse', '123456', 'Ayşe Demir', 'employee'),
  ('mehmet', '123456', 'Mehmet Kaya', 'employee'),
  ('fatma', '123456', 'Fatma Özkan', 'employee'),
  ('ali', '123456', 'Ali Çelik', 'employee');

-- Örnek iş kayıtları ekle
INSERT INTO work_entries (user_id, username, full_name, task, start_time, end_time, duration, work_date) 
SELECT 
  u.id,
  u.username,
  u.full_name,
  'Örnek iş kaydı - ' || u.full_name || ' tarafından yapıldı',
  '09:00',
  '17:00',
  '8s 0dk',
  CURRENT_DATE - INTERVAL '1 day'
FROM users u WHERE u.role = 'employee';

INSERT INTO work_entries (user_id, username, full_name, task, start_time, end_time, duration, work_date) 
SELECT 
  u.id,
  u.username,
  u.full_name,
  'Mal indirme, yükleme ve depo yardım vb.',
  '10:00',
  '15:30',
  '5s 30dk',
  CURRENT_DATE
FROM users u WHERE u.role = 'employee' LIMIT 2;

-- Başarı mesajı
SELECT 'Admin panelli veritabanı başarıyla oluşturuldu!' as message;

"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { LogOut, Clock, Plus, Trash2, Loader2, Calendar, User, Briefcase, Timer } from "lucide-react"
import { supabase, type WorkEntry, type User as UserType } from "@/lib/supabase"

interface DashboardProps {
  user: UserType
  onLogout: () => void
}

export default function Dashboard({ user, onLogout }: DashboardProps) {
  const [workEntries, setWorkEntries] = useState<WorkEntry[]>([])
  const [currentTask, setCurrentTask] = useState("")
  const [startTime, setStartTime] = useState("")
  const [endTime, setEndTime] = useState("")
  const [workDate, setWorkDate] = useState(new Date().toISOString().split("T")[0])
  const [loading, setLoading] = useState(false)
  const [fetchLoading, setFetchLoading] = useState(true)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  // Verileri yükle
  useEffect(() => {
    fetchWorkEntries()
  }, [user.id])

  const fetchWorkEntries = async () => {
    try {
      const { data, error } = await supabase
        .from("work_entries")
        .select("*")
        .eq("user_id", user.id)
        .order("work_date", { ascending: false })
        .order("created_at", { ascending: false })

      if (error) throw error
      setWorkEntries(data || [])
    } catch (error) {
      setError("Veriler yüklenirken hata oluştu")
    } finally {
      setFetchLoading(false)
    }
  }

  const calculateDuration = (start: string, end: string): string => {
    if (!start || !end) return ""

    const startDate = new Date(`2000-01-01T${start}`)
    const endDate = new Date(`2000-01-01T${end}`)

    if (endDate <= startDate) return "Geçersiz saat"

    const diffMs = endDate.getTime() - startDate.getTime()
    const hours = Math.floor(diffMs / (1000 * 60 * 60))
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60))

    return `${hours}s ${minutes}dk`
  }

  const handleAddWork = async () => {
    setError("")
    setSuccess("")

    if (!currentTask.trim() || !startTime || !endTime || !workDate) {
      setError("Lütfen tüm alanları doldurun")
      return
    }

    const duration = calculateDuration(startTime, endTime)
    if (duration === "Geçersiz saat") {
      setError("Bitiş saati başlangıç saatinden sonra olmalıdır")
      return
    }

    setLoading(true)

    try {
      const newEntry: Omit<WorkEntry, "id" | "created_at"> = {
        user_id: user.id,
        username: user.username,
        task: currentTask.trim(),
        start_time: startTime,
        end_time: endTime,
        duration,
        work_date: workDate,
      }

      const { data, error } = await supabase.from("work_entries").insert([newEntry]).select().single()

      if (error) throw error

      setWorkEntries([data, ...workEntries])
      setCurrentTask("")
      setStartTime("")
      setEndTime("")
      setSuccess("İş kaydı başarıyla eklendi!")

      // Başarı mesajını 3 saniye sonra temizle
      setTimeout(() => setSuccess(""), 3000)
    } catch (error) {
      setError("İş kaydı eklenirken hata oluştu")
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteWork = async (id: string) => {
    if (!confirm("Bu iş kaydını silmek istediğinizden emin misiniz?")) return

    try {
      const { error } = await supabase.from("work_entries").delete().eq("id", id)

      if (error) throw error

      setWorkEntries(workEntries.filter((entry) => entry.id !== id))
      setSuccess("İş kaydı silindi")
      setTimeout(() => setSuccess(""), 3000)
    } catch (error) {
      setError("İş kaydı silinirken hata oluştu")
    }
  }

  const getTotalHours = (): string => {
    let totalMinutes = 0

    workEntries.forEach((entry) => {
      const [hours, minutes] = entry.duration.split("s ")
      totalMinutes += Number.parseInt(hours) * 60 + Number.parseInt(minutes.replace("dk", ""))
    })

    const hours = Math.floor(totalMinutes / 60)
    const mins = totalMinutes % 60

    return `${hours}s ${mins}dk`
  }

  const getTodayEntries = () => {
    const today = new Date().toISOString().split("T")[0]
    return workEntries.filter((entry) => entry.work_date === today)
  }

  if (fetchLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Veriler yükleniyor...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Hoş geldin, {user.full_name || user.username}!</h1>
                <p className="text-sm text-gray-600">Çalışma kayıtlarınızı yönetin</p>
              </div>
            </div>
            <Button variant="outline" onClick={onLogout} className="flex items-center space-x-2 bg-transparent">
              <LogOut className="w-4 h-4" />
              <span>Çıkış Yap</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 space-y-6">
        {/* Bildirimler */}
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="border-green-200 bg-green-50">
            <AlertDescription className="text-green-800">{success}</AlertDescription>
          </Alert>
        )}

        {/* İstatistikler */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Briefcase className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{workEntries.length}</p>
                  <p className="text-sm text-gray-600">Toplam İş Kaydı</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Timer className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{getTotalHours()}</p>
                  <p className="text-sm text-gray-600">Toplam Çalışma</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{getTodayEntries().length}</p>
                  <p className="text-sm text-gray-600">Bugünkü Kayıtlar</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* İş Ekleme Formu */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Plus className="w-5 h-5" />
              <span>Yeni İş Kaydı Ekle</span>
            </CardTitle>
            <CardDescription>Yaptığınız işi, çalışma saatlerinizi ve tarihini girin</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="task">Yapılan İş *</Label>
              <Textarea
                id="task"
                placeholder="Bugün ne yaptınız? (örn: Müşteri raporları hazırlandı, toplantıya katılım sağlandı, proje geliştirme...)"
                value={currentTask}
                onChange={(e) => setCurrentTask(e.target.value)}
                rows={3}
                className="resize-none"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="workDate">Çalışma Tarihi *</Label>
                <Input
                  id="workDate"
                  type="date"
                  value={workDate}
                  onChange={(e) => setWorkDate(e.target.value)}
                  max={new Date().toISOString().split("T")[0]}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="startTime">Başlangıç Saati *</Label>
                <Input id="startTime" type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="endTime">Bitiş Saati *</Label>
                <Input id="endTime" type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
              </div>
            </div>

            {startTime && endTime && (
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <p className="text-sm text-blue-800 flex items-center">
                  <Clock className="w-4 h-4 mr-2" />
                  Toplam Çalışma Süresi: <strong className="ml-1">{calculateDuration(startTime, endTime)}</strong>
                </p>
              </div>
            )}

            <Button onClick={handleAddWork} className="w-full" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Kaydediliyor...
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4 mr-2" />
                  İş Kaydını Ekle
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* İş Kayıtları Listesi */}
        <Card>
          <CardHeader>
            <CardTitle>İş Kayıtlarım</CardTitle>
            <CardDescription>Tüm çalışma kayıtlarınız tarih sırasına göre listeleniyor</CardDescription>
          </CardHeader>
          <CardContent>
            {workEntries.length === 0 ? (
              <div className="text-center py-12">
                <Briefcase className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Henüz iş kaydı yok</h3>
                <p className="text-gray-600 mb-4">Yukarıdaki formu kullanarak ilk iş kaydınızı ekleyin</p>
              </div>
            ) : (
              <div className="space-y-4">
                {workEntries.map((entry) => (
                  <div key={entry.id} className="border rounded-lg p-4 bg-white hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <p className="font-medium text-gray-900 mb-3 leading-relaxed">{entry.task}</p>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="outline" className="flex items-center space-x-1">
                            <Calendar className="w-3 h-3" />
                            <span>{new Date(entry.work_date).toLocaleDateString("tr-TR")}</span>
                          </Badge>
                          <Badge variant="outline" className="flex items-center space-x-1">
                            <Clock className="w-3 h-3" />
                            <span>
                              {entry.start_time} - {entry.end_time}
                            </span>
                          </Badge>
                          <Badge variant="secondary" className="flex items-center space-x-1">
                            <Timer className="w-3 h-3" />
                            <span>{entry.duration}</span>
                          </Badge>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteWork(entry.id!)}
                        className="text-red-600 hover:text-red-800 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

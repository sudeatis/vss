"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { User, Lock, Loader2, Clock, AlertCircle, Shield } from "lucide-react"
import { supabase, type User as UserType, isSupabaseConfigured } from "@/lib/supabase"

interface LoginFormProps {
  onLogin: (user: UserType) => void
}

export default function LoginForm({ onLogin }: LoginFormProps) {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    if (!isSupabaseConfigured) {
      setError("Veritabanı yapılandırılmadı: .env.local dosyanızı kontrol edin.")
      setLoading(false)
      return
    }

    if (!username.trim() || !password.trim()) {
      setError("Kullanıcı adı ve şifre gereklidir")
      setLoading(false)
      return
    }

    try {
      const { data, error: dbError } = await supabase
        .from("users")
        .select("*")
        .eq("username", username.trim().toLowerCase())
        .eq("password", password.trim())

      if (dbError) {
        setError("Veritabanı bağlantı hatası: " + dbError.message)
        return
      }

      if (!data || data.length === 0) {
        setError("Geçersiz kullanıcı adı veya şifre")
        return
      }

      const user = data[0]
      onLogin(user)
    } catch (err: any) {
      if (err instanceof TypeError) {
        setError("Sunucuya bağlanılamıyor. İnternet bağlantınızı kontrol edin.")
      } else {
        setError("Beklenmeyen bir hata oluştu. Lütfen tekrar deneyin.")
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center">
            <Clock className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900">Çalışan Takip Sistemi</CardTitle>
          <CardDescription className="text-gray-600">
            Çalışma saatlerinizi kaydetmek veya yönetmek için giriş yapın
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-sm font-medium">
                Kullanıcı Adı
              </Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="username"
                  type="text"
                  placeholder="Kullanıcı adınızı girin"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="pl-10 h-11"
                  disabled={loading}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-medium">
                Şifre
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="password"
                  type="password"
                  placeholder="Şifrenizi girin"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 h-11"
                  disabled={loading}
                />
              </div>
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Button type="submit" className="w-full h-11" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Giriş yapılıyor...
                </>
              ) : (
                "Giriş Yap"
              )}
            </Button>
          </form>

          <div className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-800 font-medium mb-2 flex items-center">
                <User className="w-4 h-4 mr-1" />
                Çalışan Hesapları:
              </p>
              <div className="text-xs text-blue-600 space-y-1">
                <p>• ahmet / 123456</p>
                <p>• ayse / 123456</p>
                <p>• mehmet / 123456</p>
              </div>
            </div>

            <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
              <p className="text-sm text-orange-800 font-medium mb-2 flex items-center">
                <Shield className="w-4 h-4 mr-1" />
                Admin Hesabı:
              </p>
              <div className="text-xs text-orange-600">
                <p>• admin / admin123</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

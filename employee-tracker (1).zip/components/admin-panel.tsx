"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  LogOut,
  Users,
  Clock,
  Calendar,
  Briefcase,
  Search,
  Filter,
  Loader2,
  Shield,
  FileSpreadsheet,
} from "lucide-react"
import { supabase, type WorkEntry, type User } from "@/lib/supabase"
import { downloadExcel, calculateTotalHours } from "@/lib/excel-utils"

interface AdminPanelProps {
  user: User
  onLogout: () => void
}

export default function AdminPanel({ user, onLogout }: AdminPanelProps) {
  const [workEntries, setWorkEntries] = useState<WorkEntry[]>([])
  const [filteredEntries, setFilteredEntries] = useState<WorkEntry[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedUser, setSelectedUser] = useState("")
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [success, setSuccess] = useState("")

  useEffect(() => {
    fetchData()
  }, [])

  useEffect(() => {
    filterEntries()
  }, [workEntries, searchTerm, selectedUser, dateFrom, dateTo])

  const fetchData = async () => {
    try {
      // İş kayıtlarını getir
      const { data: entriesData, error: entriesError } = await supabase
        .from("work_entries")
        .select("*")
        .order("work_date", { ascending: false })
        .order("created_at", { ascending: false })

      if (entriesError) throw entriesError

      // Kullanıcıları getir
      const { data: usersData, error: usersError } = await supabase
        .from("users")
        .select("*")
        .eq("role", "employee")
        .order("full_name")

      if (usersError) throw usersError

      setWorkEntries(entriesData || [])
      setUsers(usersData || [])
    } catch (error) {
      console.error("Veri yükleme hatası:", error)
    } finally {
      setLoading(false)
    }
  }

  const filterEntries = () => {
    let filtered = [...workEntries]

    // Metin araması
    if (searchTerm) {
      filtered = filtered.filter(
        (entry) =>
          entry.task.toLowerCase().includes(searchTerm.toLowerCase()) ||
          entry.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (entry.full_name && entry.full_name.toLowerCase().includes(searchTerm.toLowerCase())),
      )
    }

    // Kullanıcı filtresi
    if (selectedUser) {
      filtered = filtered.filter((entry) => entry.username === selectedUser)
    }

    // Tarih filtresi
    if (dateFrom) {
      filtered = filtered.filter((entry) => entry.work_date >= dateFrom)
    }
    if (dateTo) {
      filtered = filtered.filter((entry) => entry.work_date <= dateTo)
    }

    setFilteredEntries(filtered)
  }

  const handleExcelDownload = () => {
    if (filteredEntries.length === 0) {
      alert("İndirilecek veri bulunamadı!")
      return
    }

    const filename = `calisan-kayitlari${selectedUser ? `-${selectedUser}` : ""}${
      dateFrom || dateTo ? `-${dateFrom || "baslangic"}-${dateTo || "bitis"}` : ""
    }`

    downloadExcel(filteredEntries, filename)
    setSuccess(`${filteredEntries.length} kayıt Excel dosyası olarak indirildi!`)
    setTimeout(() => setSuccess(""), 3000)
  }

  const getStats = () => {
    const totalEntries = filteredEntries.length
    const totalHours = calculateTotalHours(filteredEntries)
    const uniqueEmployees = new Set(filteredEntries.map((entry) => entry.username)).size
    const todayEntries = filteredEntries.filter(
      (entry) => entry.work_date === new Date().toISOString().split("T")[0],
    ).length

    return { totalEntries, totalHours, uniqueEmployees, todayEntries }
  }

  const stats = getStats()

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Veriler yükleniyor...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-orange-600 rounded-full flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Admin Paneli</h1>
                <p className="text-sm text-gray-600">Hoş geldin, {user.full_name || user.username}!</p>
              </div>
            </div>
            <Button variant="outline" onClick={onLogout} className="flex items-center space-x-2 bg-transparent">
              <LogOut className="w-4 h-4" />
              <span>Çıkış Yap</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-4 space-y-6">
        {/* Başarı mesajı */}
        {success && (
          <Alert className="border-green-200 bg-green-50">
            <AlertDescription className="text-green-800">{success}</AlertDescription>
          </Alert>
        )}

        {/* İstatistikler */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Briefcase className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalEntries}</p>
                  <p className="text-sm text-gray-600">Toplam Kayıt</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Clock className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalHours}</p>
                  <p className="text-sm text-gray-600">Toplam Süre</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{stats.uniqueEmployees}</p>
                  <p className="text-sm text-gray-600">Aktif Çalışan</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{stats.todayEntries}</p>
                  <p className="text-sm text-gray-600">Bugünkü Kayıt</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filtreler ve Excel İndirme */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center space-x-2">
                <Filter className="w-5 h-5" />
                <span>Filtreler ve Raporlar</span>
              </span>
              <Button onClick={handleExcelDownload} className="flex items-center space-x-2">
                <FileSpreadsheet className="w-4 h-4" />
                <span>Excel İndir ({filteredEntries.length} kayıt)</span>
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="search">Arama</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="search"
                    placeholder="İş, çalışan ara..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="user">Çalışan</Label>
                <select
                  id="user"
                  value={selectedUser}
                  onChange={(e) => setSelectedUser(e.target.value)}
                  className="w-full h-10 px-3 border border-gray-300 rounded-md bg-white"
                >
                  <option value="">Tüm Çalışanlar</option>
                  {users.map((user) => (
                    <option key={user.id} value={user.username}>
                      {user.full_name || user.username}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="dateFrom">Başlangıç Tarihi</Label>
                <Input id="dateFrom" type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="dateTo">Bitiş Tarihi</Label>
                <Input id="dateTo" type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* İş Kayıtları Listesi */}
        <Card>
          <CardHeader>
            <CardTitle>Tüm İş Kayıtları</CardTitle>
            <CardDescription>
              {filteredEntries.length} kayıt gösteriliyor
              {workEntries.length !== filteredEntries.length && ` (${workEntries.length} toplam)`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {filteredEntries.length === 0 ? (
              <div className="text-center py-12">
                <Briefcase className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Kayıt bulunamadı</h3>
                <p className="text-gray-600">Filtrelerinizi değiştirmeyi deneyin</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredEntries.map((entry) => (
                  <div key={entry.id} className="border rounded-lg p-4 bg-white hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <Badge variant="outline" className="font-medium">
                            {entry.full_name || entry.username}
                          </Badge>
                          <Badge variant="secondary">{new Date(entry.work_date).toLocaleDateString("tr-TR")}</Badge>
                        </div>
                        <p className="font-medium text-gray-900 mb-3 leading-relaxed">{entry.task}</p>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="outline" className="flex items-center space-x-1">
                            <Clock className="w-3 h-3" />
                            <span>
                              {entry.start_time} - {entry.end_time}
                            </span>
                          </Badge>
                          <Badge variant="secondary" className="flex items-center space-x-1">
                            <span>{entry.duration}</span>
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

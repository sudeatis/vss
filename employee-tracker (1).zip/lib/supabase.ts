import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "http://localhost-placeholder-url"
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "local-placeholder-key"

const envMissing = !process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

if (envMissing && typeof window !== "undefined") {
  console.warn("⚠️ Supabase env değişkenleri tanımlı değil - Preview modunda çalışıyor")
}

export const supabase = createClient(supabaseUrl, supabaseKey, {
  global: { fetch },
})

export type WorkEntry = {
  id?: string
  user_id: string
  username: string
  full_name?: string
  task: string
  start_time: string
  end_time: string
  duration: string
  work_date: string
  created_at?: string
}

export type User = {
  id: string
  username: string
  password: string
  full_name?: string
  role?: string
  created_at?: string
}

export const isSupabaseConfigured = !envMissing

import type { WorkEntry } from "./supabase"

export const downloadExcel = (data: WorkEntry[], filename = "calisan-kayitlari") => {
  // CSV formatında veri hazırla
  const headers = ["Tarih", "Çalışan", "Ad Soyad", "Yapılan İş", "Başlangıç", "Bitiş", "Süre"]

  const csvContent = [
    headers.join(","),
    ...data.map((entry) =>
      [
        entry.work_date,
        entry.username,
        entry.full_name || "",
        `"${entry.task.replace(/"/g, '""')}"`, // CSV için tırnak escape
        entry.start_time,
        entry.end_time,
        entry.duration,
      ].join(","),
    ),
  ].join("\n")

  // BOM ekle (Türkçe karakterler için)
  const BOM = "\uFEFF"
  const blob = new Blob([BOM + csvContent], { type: "text/csv;charset=utf-8;" })

  // İndirme linki oluştur
  const link = document.createElement("a")
  const url = URL.createObjectURL(blob)
  link.setAttribute("href", url)
  link.setAttribute("download", `${filename}-${new Date().toISOString().split("T")[0]}.csv`)
  link.style.visibility = "hidden"
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

export const calculateTotalHours = (entries: WorkEntry[]): string => {
  let totalMinutes = 0

  entries.forEach((entry) => {
    const [hours, minutes] = entry.duration.split("s ")
    totalMinutes += Number.parseInt(hours) * 60 + Number.parseInt(minutes.replace("dk", ""))
  })

  const hours = Math.floor(totalMinutes / 60)
  const mins = totalMinutes % 60

  return `${hours}s ${mins}dk`
}

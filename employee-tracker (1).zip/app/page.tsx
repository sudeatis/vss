"use client"

import { useState } from "react"
import LoginForm from "@/components/login-form"
import AdminPanel from "@/components/admin-panel"
import EmployeeDashboard from "@/components/employee-dashboard"
import type { User } from "@/lib/supabase"

export default function Home() {
  const [currentUser, setCurrentUser] = useState<User | null>(null)

  const handleLogin = (user: User) => {
    setCurrentUser(user)
  }

  const handleLogout = () => {
    setCurrentUser(null)
  }

  if (!currentUser) {
    return <LoginForm onLogin={handleLogin} />
  }

  // Admin paneli veya çalışan dashboard'u göster
  if (currentUser.role === "admin") {
    return <AdminPanel user={currentUser} onLogout={handleLogout} />
  }

  return <EmployeeDashboard user={currentUser} onLogout={handleLogout} />
}
